-- Add new columns to postAnalysis table
ALTER TABLE `postAnalysis` ADD COLUMN `hashtags` text;
ALTER TABLE `postAnalysis` ADD COLUMN `sentiment` varchar(32);
ALTER TABLE `postAnalysis` ADD COLUMN `engagementRate` varchar(16);
ALTER TABLE `postAnalysis` ADD COLUMN `recommendations` text;

-- Add unique index on (userId, instagramPostId)
CREATE UNIQUE INDEX `userId_postId_idx` ON `postAnalysis` (`userId`, `instagramPostId`);

-- Create apiCache table
CREATE TABLE `apiCache` (
        `id` int AUTO_INCREMENT NOT NULL,
        `userId` int NOT NULL,
        `cacheKey` varchar(255) NOT NULL,
        `responseData` text NOT NULL,
        `expiresAt` timestamp NOT NULL,
        `createdAt` timestamp NOT NULL DEFAULT (now()),
        CONSTRAINT `apiCache_id` PRIMARY KEY(`id`)
);

-- Create unique index on apiCache
CREATE UNIQUE INDEX `userId_cacheKey_idx` ON `apiCache` (`userId`, `cacheKey`);
CREATE INDEX `expiresAt_idx` ON `apiCache` (`expiresAt`);

-- Create postInsights table
CREATE TABLE `postInsights` (
        `id` int AUTO_INCREMENT NOT NULL,
        `userId` int NOT NULL,
        `instagramPostId` varchar(64) NOT NULL,
        `likeCount` int DEFAULT 0 NOT NULL,
        `commentsCount` int DEFAULT 0 NOT NULL,
        `reach` int DEFAULT 0 NOT NULL,
        `impressions` int DEFAULT 0 NOT NULL,
        `savedCount` int DEFAULT 0,
        `sharesCount` int DEFAULT 0,
        `fetchedAt` timestamp NOT NULL DEFAULT (now()),
        CONSTRAINT `postInsights_id` PRIMARY KEY(`id`)
);

-- Create unique index on postInsights
CREATE UNIQUE INDEX `userId_insightsPostId_idx` ON `postInsights` (`userId`, `instagramPostId`);
