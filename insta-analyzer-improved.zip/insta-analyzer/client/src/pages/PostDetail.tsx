import { useParams } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, Copy, Loader2, ArrowLeft, Heart, MessageCircle, Eye, EyeOff, Bookmark, Share2, RefreshCw, Tag } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type NormalizedPost = {
  id: string;
  caption?: string;
  mediaType: "post" | "reel" | "story" | "carousel";
  mediaUrl?: string;
  timestamp?: Date;
  permalink?: string;
  rawMediaType: string;
  hashtags: string[];
};

type AnalysisData = {
  description: string;
  contentCategory: string;
  script: string;
  hashtags: string[];
  sentiment: "positive" | "negative" | "neutral";
  recommendations: string[];
};

type PostInsights = {
  likeCount: number;
  commentsCount: number;
  reach: number;
  impressions: number;
  savedCount: number;
  sharesCount: number;
  engagementRate: number;
};

const getContentTypeColor = (type: "post" | "reel" | "story" | "carousel") => {
  switch (type) {
    case "reel":
      return "bg-accent text-accent-foreground";
    case "carousel":
      return "bg-secondary text-secondary-foreground";
    case "story":
      return "bg-destructive text-destructive-foreground";
    default:
      return "bg-primary text-primary-foreground";
  }
};

const getSentimentColor = (sentiment: string) => {
  switch (sentiment) {
    case "positive":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
    case "negative":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
    default:
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  }
};

const formatNumber = (num: number): string => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
};

const copyToClipboard = async (text: string, label: string) => {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  } catch (error) {
    toast.error(`Failed to copy ${label}`);
  }
};

export default function PostDetail() {
  const params = useParams();
  const postId = params?.id as string;
  const [, setLocation] = useLocation();

  // Fetch the actual post data from the backend
  const { data: post, isLoading: isLoadingPost, error: postError } = trpc.instagram.getPostById.useQuery(
    { postId },
    { enabled: !!postId }
  );

  // Analyze post
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);
  const analyzePostMutation = trpc.instagram.analyzePost.useMutation();

  // Fetch insights
  const { data: insights, isLoading: isLoadingInsights } =
    trpc.instagram.getPostInsights.useQuery(
      { postId },
      { enabled: !!postId }
    );

  const insightData = (insights || {}) as PostInsights;
  const typedPost = post as NormalizedPost | undefined;
  const contentType = typedPost?.mediaType || "post";

  // Trigger analysis when post data is available
  useEffect(() => {
    if (typedPost?.caption && !analysisData && !isLoadingAnalysis) {
      setIsLoadingAnalysis(true);
      analyzePostMutation.mutate(
        {
          postId: typedPost.id,
          caption: typedPost.caption,
          mediaType: contentType,
        },
        {
          onSuccess: (data: AnalysisData) => {
            setAnalysisData(data);
            setIsLoadingAnalysis(false);
          },
          onError: () => {
            setIsLoadingAnalysis(false);
            toast.error("Failed to analyze post");
          },
        }
      );
    }
  }, [typedPost?.id, typedPost?.caption, contentType]);

  // Re-analyze handler
  const handleReAnalyze = () => {
    if (!typedPost?.caption) return;
    setIsLoadingAnalysis(true);
    setAnalysisData(null);
    analyzePostMutation.mutate(
      {
        postId: typedPost.id,
        caption: typedPost.caption,
        mediaType: contentType,
        forceReanalyze: true,
      },
      {
        onSuccess: (data: AnalysisData) => {
          setAnalysisData(data);
          setIsLoadingAnalysis(false);
          toast.success("Analysis refreshed");
        },
        onError: () => {
          setIsLoadingAnalysis(false);
          toast.error("Failed to re-analyze post");
        },
      }
    );
  };

  // Error state for post loading
  if (postError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-96 gap-4">
        <AlertCircle className="h-12 w-12 text-destructive" />
        <div className="text-center space-y-2">
          <h2 className="text-lg font-semibold">Failed to load post</h2>
          <p className="text-sm text-muted-foreground">
            {postError.message || "Please check your Instagram connection and try again."}
          </p>
        </div>
        <Button variant="outline" onClick={() => setLocation("/posts")}>
          Back to Posts
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation("/posts")}
        className="gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Posts
      </Button>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Media Preview */}
          <Card className="overflow-hidden shadow-premium-lg">
            <CardContent className="p-0">
              <div className="relative bg-muted">
                {isLoadingPost ? (
                  <Skeleton className="w-full h-96" />
                ) : typedPost?.mediaUrl ? (
                  <img
                    src={typedPost.mediaUrl}
                    alt={typedPost.caption || "Instagram post"}
                    className="w-full h-auto max-h-96 object-cover"
                  />
                ) : (
                  <div className="w-full h-96 flex items-center justify-center bg-secondary/10">
                    <span className="text-muted-foreground">No preview</span>
                  </div>
                )}

                {/* Content Type Badge */}
                <Badge
                  className={`absolute top-4 right-4 capitalize text-sm ${getContentTypeColor(
                    contentType
                  )}`}
                >
                  {contentType}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Caption */}
          {typedPost?.caption && (
            <Card className="shadow-premium">
              <CardHeader>
                <CardTitle className="text-lg">Caption</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground whitespace-pre-wrap">{typedPost.caption}</p>
                {/* Hashtags */}
                {typedPost.hashtags && typedPost.hashtags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <Tag className="h-3.5 w-3.5 text-muted-foreground mt-0.5" />
                    {typedPost.hashtags.map((tag) => (
                      <span key={tag} className="text-xs text-primary hover:underline cursor-pointer">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* AI Analysis */}
          <Card className="shadow-premium-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">AI Analysis</CardTitle>
                  <CardDescription>
                    AI-powered insights about your content
                  </CardDescription>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleReAnalyze}
                  disabled={isLoadingAnalysis || !typedPost?.caption}
                  className="gap-2"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${isLoadingAnalysis ? "animate-spin" : ""}`} />
                  Re-analyze
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoadingAnalysis ? (
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                </div>
              ) : analysisData ? (
                <>
                  {/* Description */}
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <h3 className="font-semibold text-sm">Description</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          copyToClipboard(analysisData.description, "Description")
                        }
                        className="gap-2"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-sm text-foreground">
                      {analysisData.description}
                    </p>
                  </div>

                  {/* Content Category & Sentiment */}
                  <div className="flex gap-3 items-center flex-wrap">
                    <div className="space-y-2">
                      <h3 className="font-semibold text-sm">Category</h3>
                      <Badge variant="secondary" className="capitalize">
                        {analysisData.contentCategory}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold text-sm">Sentiment</h3>
                      <Badge className={`capitalize ${getSentimentColor(analysisData.sentiment || "neutral")}`}>
                        {analysisData.sentiment || "neutral"}
                      </Badge>
                    </div>
                  </div>

                  {/* Script */}
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <h3 className="font-semibold text-sm">Generated Script</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          copyToClipboard(analysisData.script, "Script")
                        }
                        className="gap-2"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="bg-secondary/10 p-3 rounded-lg">
                      <p className="text-sm text-foreground whitespace-pre-wrap">
                        {analysisData.script}
                      </p>
                    </div>
                  </div>

                  {/* Recommendations */}
                  {analysisData.recommendations && analysisData.recommendations.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="font-semibold text-sm">Recommendations</h3>
                      <ul className="space-y-1.5">
                        {analysisData.recommendations.map((rec, i) => (
                          <li key={i} className="text-sm text-foreground flex gap-2">
                            <span className="text-primary font-medium shrink-0">{i + 1}.</span>
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No analysis available
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar - Metrics */}
        <div className="space-y-6">
          {/* Post Info */}
          <Card className="shadow-premium">
            <CardHeader>
              <CardTitle className="text-lg">Post Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">
                  Type
                </p>
                <p className="text-sm font-medium capitalize">{contentType}</p>
              </div>
              {typedPost?.timestamp && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">
                    Published
                  </p>
                  <p className="text-sm font-medium">
                    {new Date(typedPost.timestamp).toLocaleDateString()}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Engagement Metrics */}
          <Card className="shadow-premium">
            <CardHeader>
              <CardTitle className="text-lg">Engagement</CardTitle>
              <CardDescription>
                {isLoadingInsights ? "Loading metrics..." : "Post performance"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoadingInsights ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : (
                <>
                  {/* Engagement Rate - Highlighted */}
                  {insightData.engagementRate > 0 && (
                    <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg border border-primary/20">
                      <div className="flex items-center gap-2">
                        <Eye className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Engagement Rate</span>
                      </div>
                      <span className="font-bold text-primary">
                        {insightData.engagementRate}%
                      </span>
                    </div>
                  )}

                  {/* Likes */}
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Heart className="h-4 w-4 text-destructive" />
                      <span className="text-sm text-muted-foreground">Likes</span>
                    </div>
                    <span className="font-semibold">
                      {formatNumber(insightData.likeCount || 0)}
                    </span>
                  </div>

                  {/* Comments */}
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <div className="flex items-center gap-2">
                      <MessageCircle className="h-4 w-4 text-accent" />
                      <span className="text-sm text-muted-foreground">Comments</span>
                    </div>
                    <span className="font-semibold">
                      {formatNumber(insightData.commentsCount || 0)}
                    </span>
                  </div>

                  {/* Reach */}
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4 text-primary" />
                      <span className="text-sm text-muted-foreground">Reach</span>
                    </div>
                    <span className="font-semibold">
                      {formatNumber(insightData.reach || 0)}
                    </span>
                  </div>

                  {/* Impressions */}
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <div className="flex items-center gap-2">
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Impressions</span>
                    </div>
                    <span className="font-semibold">
                      {formatNumber(insightData.impressions || 0)}
                    </span>
                  </div>

                  {/* Saves */}
                  {(insightData.savedCount > 0) && (
                    <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Bookmark className="h-4 w-4 text-amber-500" />
                        <span className="text-sm text-muted-foreground">Saves</span>
                      </div>
                      <span className="font-semibold">
                        {formatNumber(insightData.savedCount)}
                      </span>
                    </div>
                  )}

                  {/* Shares */}
                  {(insightData.sharesCount > 0) && (
                    <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Share2 className="h-4 w-4 text-blue-500" />
                        <span className="text-sm text-muted-foreground">Shares</span>
                      </div>
                      <span className="font-semibold">
                        {formatNumber(insightData.sharesCount)}
                      </span>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="shadow-premium">
            <CardHeader>
              <CardTitle className="text-lg">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {typedPost?.permalink && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => window.open(typedPost.permalink, "_blank")}
                >
                  View on Instagram
                </Button>
              )}
              {typedPost?.caption && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => copyToClipboard(typedPost.caption, "Caption")}
                >
                  Copy Caption
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
