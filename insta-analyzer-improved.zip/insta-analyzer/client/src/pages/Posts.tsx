import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, ChevronRight, Loader2, Eye, Heart, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

type NormalizedPost = {
  id: string;
  caption?: string;
  mediaType: "post" | "reel" | "story" | "carousel";
  mediaUrl?: string;
  timestamp?: Date;
  permalink?: string;
  rawMediaType: string;
  hashtags: string[];
};

const getContentTypeColor = (type: "post" | "reel" | "story" | "carousel") => {
  switch (type) {
    case "reel":
      return "bg-accent text-accent-foreground";
    case "carousel":
      return "bg-secondary text-secondary-foreground";
    case "story":
      return "bg-destructive text-destructive-foreground";
    default:
      return "bg-primary text-primary-foreground";
  }
};

const formatNumber = (num: number): string => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
};

export default function Posts() {
  const [, setLocation] = useLocation();
  const [pageCursor, setPageCursor] = useState<string | undefined>();
  const [allPosts, setAllPosts] = useState<NormalizedPost[]>([]);
  const [hasLoaded, setHasLoaded] = useState(false);

  const { data, isLoading, error, isFetching } = trpc.instagram.getPosts.useQuery(
    {
      limit: 10,
      pageCursor,
    },
    {
      // Don't refetch on window focus for smoother UX
      refetchOnWindowFocus: false,
      // Keep previous data while loading more
      placeholderData: (prev) => prev,
    }
  );

  // Append new posts to the existing list when data changes
  const newPosts = data?.posts || [];
  const nextPageCursor = data?.nextCursor;

  // Update allPosts when data changes
  if (newPosts.length > 0 && !isFetching) {
    // Check if these are new posts (not already in the list)
    const existingIds = new Set(allPosts.map(p => p.id));
    const hasNewPosts = newPosts.some(p => !existingIds.has(p.id));

    if (hasNewPosts) {
      if (pageCursor) {
        // Loading more - append
        setAllPosts(prev => {
          const existingIds = new Set(prev.map(p => p.id));
          const toAdd = newPosts.filter(p => !existingIds.has(p.id));
          return [...prev, ...toAdd];
        });
      } else {
        // First load or refresh - replace
        setAllPosts(newPosts as NormalizedPost[]);
      }
      setHasLoaded(true);
    }
  }

  // Initial loading state
  if (isLoading && !hasLoaded) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold tracking-tight">Your Posts</h1>
          <p className="text-muted-foreground">Browse and analyze your recent Instagram content</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-64 w-full" />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-96 gap-4">
        <AlertCircle className="h-12 w-12 text-destructive" />
        <div className="text-center space-y-2">
          <h2 className="text-lg font-semibold">Failed to load posts</h2>
          <p className="text-sm text-muted-foreground">
            {error.message || "Please check your Instagram connection and try again."}
          </p>
        </div>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight">Your Posts</h1>
        <p className="text-muted-foreground">
          Browse and analyze your recent Instagram content
          {allPosts.length > 0 && (
            <span className="text-muted-foreground ml-1">
              ({allPosts.length} posts loaded)
            </span>
          )}
        </p>
      </div>

      {/* Posts Grid */}
      {allPosts.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-96 gap-4">
          <div className="text-center space-y-2">
            <h2 className="text-lg font-semibold">No posts found</h2>
            <p className="text-sm text-muted-foreground">
              Make sure your Instagram account is connected and you have published content.
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {allPosts.map((post: NormalizedPost) => {
              const contentType = post.mediaType;
              const mediaUrl = post.mediaUrl || "";

              return (
                <Card
                  key={post.id}
                  className="overflow-hidden shadow-premium hover:shadow-premium-lg transition-all duration-300 cursor-pointer group"
                  onClick={() => setLocation(`/posts/${post.id}`)}
                >
                  <CardContent className="p-0">
                    {/* Media Preview */}
                    <div className="relative h-64 bg-muted overflow-hidden">
                      {mediaUrl ? (
                        <img
                          src={mediaUrl}
                          alt={post.caption || "Instagram post"}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-secondary/10">
                          <span className="text-muted-foreground text-sm">No preview</span>
                        </div>
                      )}

                      {/* Content Type Badge */}
                      <Badge
                        className={`absolute top-3 right-3 capitalize ${getContentTypeColor(
                          contentType
                        )}`}
                      >
                        {contentType}
                      </Badge>
                    </div>

                    {/* Post Info */}
                    <div className="p-4 space-y-3">
                      {post.caption && (
                        <p className="text-sm line-clamp-2 text-foreground">
                          {post.caption}
                        </p>
                      )}

                      {/* Hashtags Preview */}
                      {post.hashtags && post.hashtags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {post.hashtags.slice(0, 3).map((tag) => (
                            <span key={tag} className="text-xs text-primary">
                              #{tag}
                            </span>
                          ))}
                          {post.hashtags.length > 3 && (
                            <span className="text-xs text-muted-foreground">
                              +{post.hashtags.length - 3} more
                            </span>
                          )}
                        </div>
                      )}

                      {post.timestamp && (
                        <p className="text-xs text-muted-foreground">
                          {new Date(post.timestamp).toLocaleDateString()}
                        </p>
                      )}

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full group/btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/posts/${post.id}`);
                        }}
                      >
                        View Details
                        <ChevronRight className="h-4 w-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Pagination */}
          {nextPageCursor && (
            <div className="flex justify-center pt-4">
              <Button
                onClick={() => setPageCursor(nextPageCursor)}
                variant="outline"
                disabled={isFetching}
              >
                {isFetching ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Loading more...
                  </>
                ) : (
                  "Load More Posts"
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
