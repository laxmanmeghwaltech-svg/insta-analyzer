import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, TrendingUp, Zap, Heart, MessageCircle, Eye, Hash, RefreshCw, Clock, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

const formatNumber = (num: number): string => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
};

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const formatHour = (hour: number): string => {
  const ampm = hour >= 12 ? "PM" : "AM";
  const h = hour % 12 || 12;
  return `${h} ${ampm}`;
};

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch analytics overview
  const { data: analytics, isLoading: isLoadingAnalytics, refetch: refetchAnalytics } =
    trpc.instagram.getAnalyticsOverview.useQuery(undefined, {
      refetchOnWindowFocus: false,
    });

  // Fetch best posting times
  const { data: postingTimes, isLoading: isLoadingTimes } =
    trpc.instagram.getBestPostingTimes.useQuery(undefined, {
      refetchOnWindowFocus: false,
    });

  const insights = analytics?.insights;
  const categories = analytics?.categories || [];
  const sentiments = analytics?.sentiments || [];
  const topHashtags = analytics?.topHashtags || [];
  const contentStrategy = analytics?.contentStrategy || "";

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold tracking-tight">
            Welcome back, {user?.name || "Creator"}
          </h1>
          <p className="text-muted-foreground">
            Analyze, understand, and repurpose your Instagram content with AI-powered insights.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetchAnalytics()}
          className="gap-2"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-l-4 border-l-red-500 shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Heart className="h-4 w-4 text-red-500" />
              Total Likes
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <p className="text-2xl font-bold">
                {formatNumber(insights?.totalLikes || 0)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500 shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <MessageCircle className="h-4 w-4 text-blue-500" />
              Total Comments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <p className="text-2xl font-bold">
                {formatNumber(insights?.totalComments || 0)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500 shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Eye className="h-4 w-4 text-green-500" />
              Total Reach
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <p className="text-2xl font-bold">
                {formatNumber(insights?.totalReach || 0)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-primary shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-primary" />
              Avg Engagement
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <p className="text-2xl font-bold">
                {insights?.avgEngagementRate || 0}%
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Content Categories */}
        <Card className="shadow-premium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-accent" />
              Content Categories
            </CardTitle>
            <CardDescription>
              Distribution of your content types
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <div className="space-y-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full" />
                ))}
              </div>
            ) : categories.length > 0 ? (
              <div className="space-y-3">
                {categories.map((cat) => {
                  const maxCount = Math.max(...categories.map(c => c.count));
                  const widthPercent = maxCount > 0 ? (cat.count / maxCount) * 100 : 0;
                  return (
                    <div key={cat.category} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="capitalize font-medium">{cat.category || "uncategorized"}</span>
                        <span className="text-muted-foreground">{cat.count} posts</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary rounded-full transition-all duration-500"
                          style={{ width: `${widthPercent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Analyze your posts to see category distribution
              </p>
            )}
          </CardContent>
        </Card>

        {/* Top Hashtags */}
        <Card className="shadow-premium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hash className="h-5 w-5 text-accent" />
              Top Hashtags
            </CardTitle>
            <CardDescription>
              Most frequently used hashtags in your content
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <Skeleton key={i} className="h-6 w-20 rounded-full" />
                ))}
              </div>
            ) : topHashtags.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {topHashtags.map((hashtag) => (
                  <Badge key={hashtag.tag} variant="secondary" className="gap-1">
                    #{hashtag.tag}
                    <span className="text-xs text-muted-foreground">({hashtag.count})</span>
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Analyze your posts to see top hashtags
              </p>
            )}
          </CardContent>
        </Card>

        {/* Best Posting Times */}
        <Card className="shadow-premium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-accent" />
              Best Posting Times
            </CardTitle>
            <CardDescription>
              Optimal times based on your engagement data
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingTimes ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : postingTimes?.bestTimes && postingTimes.bestTimes.length > 0 ? (
              <div className="space-y-2">
                {postingTimes.bestTimes.map((time, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 bg-secondary/10 rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">
                        {DAY_NAMES[time.dayOfWeek]}
                      </span>
                      <span className="text-sm text-muted-foreground">at</span>
                      <span className="text-sm font-medium">
                        {formatHour(time.hour)}
                      </span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {time.avgEngagement}% avg engagement
                    </Badge>
                  </div>
                ))}
                <p className="text-xs text-muted-foreground mt-2">
                  Based on {postingTimes.totalPostsAnalyzed} posts analyzed
                </p>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Need more post data to determine optimal posting times
              </p>
            )}
          </CardContent>
        </Card>

        {/* Sentiment Overview */}
        <Card className="shadow-premium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-accent" />
              Sentiment Overview
            </CardTitle>
            <CardDescription>
              Emotional tone distribution in your content
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAnalytics ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full" />
                ))}
              </div>
            ) : sentiments.length > 0 ? (
              <div className="space-y-3">
                {sentiments.map((s) => {
                  const totalSentiment = sentiments.reduce((sum, x) => sum + x.count, 0);
                  const percent = totalSentiment > 0 ? Math.round((s.count / totalSentiment) * 100) : 0;
                  const colorClass =
                    s.sentiment === "positive"
                      ? "bg-green-500"
                      : s.sentiment === "negative"
                        ? "bg-red-500"
                        : "bg-gray-400";
                  return (
                    <div key={s.sentiment} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="capitalize font-medium">{s.sentiment || "unknown"}</span>
                        <span className="text-muted-foreground">{percent}% ({s.count})</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${colorClass}`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Analyze your posts to see sentiment distribution
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* AI Content Strategy */}
      {contentStrategy && (
        <Card className="shadow-premium-lg border-l-4 border-l-accent">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-accent" />
              AI Content Strategy
            </CardTitle>
            <CardDescription>
              Personalized recommendations based on your content performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed">{contentStrategy}</p>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="shadow-premium hover:shadow-premium-lg transition-shadow cursor-pointer" onClick={() => setLocation("/posts")}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              View Posts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-foreground">
              Browse and analyze your Instagram content with AI-powered insights.
            </p>
            <Button className="w-full mt-3" size="sm">
              Go to Posts
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Sparkles className="h-4 w-4" />
              AI Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-foreground">
              Get natural language descriptions, scripts, and recommendations for each post.
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-premium hover:shadow-premium-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              Engagement Tracking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-foreground">
              Track likes, comments, reach, saves, and shares with engagement rate calculations.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
